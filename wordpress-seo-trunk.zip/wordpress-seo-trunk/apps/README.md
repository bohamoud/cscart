### Apps

This folder includes apps for testing purposes. These apps are not published. Apps include:

- [Components](apps/components)
  - A test application for most `@yoast` packages.
- [Content-analysis](apps/content-analysis)
  - A test application for the content analysis.