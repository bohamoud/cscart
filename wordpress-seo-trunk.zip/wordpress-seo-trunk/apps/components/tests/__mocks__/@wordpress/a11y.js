import { noop } from "lodash-es";

export const setup = noop;
export const speak = noop;
