import { combineReducers } from "redux";
import contentAnalysis from "yoast-components/composites/Plugin/ContentAnalysis/reducers/contentAnalysisReducer";

export default combineReducers( {
	contentAnalysis,
} );
