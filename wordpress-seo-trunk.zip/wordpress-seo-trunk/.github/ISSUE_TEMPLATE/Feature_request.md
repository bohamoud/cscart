---
name: Feature request
about: Suggest an idea for this project

---

<!-- Before opening a new issue, please search for duplicate issues to prevent opening a duplicate feature request. If there is already an open existing request, please leave a comment there. -->

## Is your feature request related to a problem? Please describe.

## Describe the solution you'd like

## Why do you think this feature is something we should consider for the Yoast SEO plugins?

## Additional context
