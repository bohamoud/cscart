---
name: Design implementation
about: Transfer a design to the development team.

---

Product owner:
UX designer:

### What are we going to build? 
<!-- If there are multiple iterative stages of implementation, describe each iteration separately -->
<!-- Describe the project scope as detailed as possible -->

### What problem does it solve?
<!-- What is the aim of this change? Why are we doing this? -->
<!-- You can copy the problem definition from the corresponding design issue -->

### Designs
#### Functional prototype
<!-- Paste link to functional prototype (in Sketch Cloud) -->

#### Design files
<!-- Paste link to design files (in Sketch Cloud) -->

### Additional info or requirements
