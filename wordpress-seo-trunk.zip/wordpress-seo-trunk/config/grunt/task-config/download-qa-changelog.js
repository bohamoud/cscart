// Custom task
module.exports = {
	"wordpress-seo": {
		options: {

		},
	},
};
