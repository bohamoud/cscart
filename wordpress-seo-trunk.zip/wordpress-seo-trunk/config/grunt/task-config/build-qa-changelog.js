// Custom task
module.exports = {
	"wordpress-seo": {
		options: {
			useEditDistanceCompare: false,
			addTheseExtraFiles: [ ],
		},
	},
};
