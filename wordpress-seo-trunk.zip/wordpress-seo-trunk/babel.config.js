module.exports = {
	presets: [ "@yoast/babel-preset" ],
};
